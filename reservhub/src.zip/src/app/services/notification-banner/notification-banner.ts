import { Component } from '@angular/core';

@Component({
  selector: 'app-notification-banner',
  imports: [],
  templateUrl: './notification-banner.html',
  styleUrl: './notification-banner.scss'
})
export class NotificationBanner {

}
