import { Component, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryCard } from '../../shared/category-card/category-card';
import { Category } from '../../models/category.model';
import { CATEGORIES, TEXTS } from '../../models/texts';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CategoryCard],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard {
  protected readonly categories = signal<Category[]>(CATEGORIES);
  protected readonly title = signal(TEXTS.dashboard.title);
  protected readonly subtitle = signal(TEXTS.dashboard.subtitle);

  constructor(private router: Router) {}

  onCategoryClick(category: Category): void {
    this.router.navigate([category.route]);
  }
}