import { Component } from '@angular/core';

@Component({
  selector: 'app-usg',
  imports: [],
  templateUrl: './usg.html',
  styleUrl: './usg.scss'
})
export class Usg {

}
