import { Component } from '@angular/core';

@Component({
  selector: 'app-employer-info',
  imports: [],
  templateUrl: './employer-info.html',
  styleUrl: './employer-info.scss'
})
export class EmployerInfo {

}
