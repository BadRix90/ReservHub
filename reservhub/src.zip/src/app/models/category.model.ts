export interface Category {
  id: string;
  title: string;
  icon: string;
  color: string;
  description: string;
  route: string;
}