import { Component } from '@angular/core';

@Component({
  selector: 'app-language-switch',
  imports: [],
  templateUrl: './language-switch.html',
  styleUrl: './language-switch.scss'
})
export class LanguageSwitch {

}
